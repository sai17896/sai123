package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Employee;
import com.cg.service.EmployeeServiceImpl;

@RestController("/employee")
public class EmployeeRestController {

	@Autowired
	EmployeeServiceImpl employeeServiceimpl;
	@Autowired
	Employee employee;

	/**
	 * @return http://localhost:8088/add/sheetal/bangalore/20000/employee
	 */
	@PostMapping("/add/{name}/{address}/{salary}/{designation}")
	public Employee addEmployee(@PathVariable String name, @PathVariable String address, @PathVariable double salary,
			@PathVariable String designation) {
		employee.setName(name);
		employee.setAddress(address);
		employee.setSalary(salary);
		employee.setDesignation(designation);
		Employee employeeSaved = employeeServiceimpl.addEmployee(employee);
		return employeeSaved;
	}

	/**
	 * get
	 * 
	 * @return http://localhost:8088/viewall
	 */
	@GetMapping("/viewall")
	public List<Employee> viewAll() {
		return employeeServiceimpl.getEmployee();
	}

	// get
	// http://localhost:8088/addobject
	@PostMapping(value = "/addobject", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public Employee addEmpObject(@RequestBody Employee e) {
		return employeeServiceimpl.addEmployee(e);
	}

	// get
	// http://localhost:8088/viewaddress?address=bangalore
	@GetMapping("/viewaddress")
	public List<Employee> viewAddress(@RequestParam String address) {
		return employeeServiceimpl.getEmployeeByAddress(address);
	}

	// get
	// http://localhost:8088/viewaddress/bangalore
	@GetMapping("/viewaddress/{address}")
	public List<Employee> viewAddressPath(@PathVariable String address) {
		return employeeServiceimpl.getEmployeeByAddress(address);
	}

	// get
	// http://localhost:8088/viewdesignation?designation=trainee
	@GetMapping("/viewdesignation")
	public List<Employee> viewByDesignationRequestParam(@RequestParam String designation) {
		return employeeServiceimpl.getEmployeeByDesignation(designation);
	}

	// get
	// http://localhost:8088/viewdesignation/softwareenginerr
	@GetMapping("/viewdesignation/{designation}")
	public List<Employee> viewDesignationPath(@PathVariable String designation) {
		return employeeServiceimpl.getEmployeeByDesignation(designation);
	}

	// Get
	// http://localhost:8088/deletebyid/3000
	@DeleteMapping("/deletebyid/{empId}")
	public void deleteById(@PathVariable Integer empId) {
		employeeServiceimpl.deleteById(empId);
	}

	// Get
	// http://localhost:8088/deleteall
	@DeleteMapping("/deleteall")
	public void deleteAll() {
		employeeServiceimpl.deleteAll();
	}

	// Get
	// http://localhost:8088/findById/3000
	@GetMapping("findById/{empId}")
	public Employee findById(@PathVariable Integer empId) {
		return employeeServiceimpl.findById(empId);
	}

	// Get
	// http://localhost:8088/salaryrange/10000/60000
	@GetMapping("/salaryrange/{salary1}/{salary2}")
	public List<Employee> salaryRange(@PathVariable Double salary1, @PathVariable Double salary2) {
		return employeeServiceimpl.salaryRange(salary1, salary2);
	}

	@DeleteMapping("/deletebyidstring/{empId}")
	public String deleteByIdString(@PathVariable Integer empId) {
		employeeServiceimpl.deleteById(empId);
		return empId+"deleted";
	}

	/*
	 * get localhost:8088/salaryrange?salary1=1000@salary2=60000
	 */
	@GetMapping("/salaryrange")
	public List<Employee> salaryRangeRequestParam(@RequestParam Double salary1, @RequestParam Double salary2) {
		return employeeServiceimpl.salaryRange(salary1, salary2);
	}

	/**
	 * put 
	 * localhost:8088/updateobject
	 */

	@PutMapping(value = "/updateobject", consumes = { MediaType.APPLICATION_JSON_VALUE })
	public Employee updateEmployee(@RequestBody Employee e) {
		return employeeServiceimpl.updateEmployee(e);
	}

	/**
	 * For Exception Handling
	 */
	/*
	 * @ResponseStatus(value =
	 * HttpStatus.NOT_FOUND,reason="Invalid request/Employee Id not Found")
	 * 
	 * @ExceptionHandler({Exception.class}) public void handleException() {
	 * 
	 * }
	 */
}
