package com.cg.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.beans.Employee;
import com.cg.dao.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements IEmployeeService {
		
	@Autowired
	EmployeeRepository employeeRepository;

	@Transactional
	@Override
	public Employee addEmployee(Employee employee) {
		
		return employeeRepository.save(employee);
	}

	@Transactional
	@Override
	public void deleteAll() {
		employeeRepository.deleteAll();
	}

	@Transactional
	@Override
	public void deleteById(Integer empId) {
		employeeRepository.deleteById(empId);
	}

	@Override
	public List<Employee> getEmployee() {
		return employeeRepository.findAll();
	}

	@Override
	public List<Employee> getEmployeeByDesignation(String designation) {
		return employeeRepository.findByDesignation(designation);
	}

	@Override
	public List<Employee> getEmployeeByAddress(String address) {
		return employeeRepository.findByAddress(address);
	}

	@Override
	public Employee findById(Integer empId) {
		return employeeRepository.findById(empId).get();
	}

	@Transactional
	@Override
	public Employee updateEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public List<Employee> salaryRange(Double salary1, Double salary2) {
		return employeeRepository.listBySalaryRange(salary1, salary2);
	}
}
