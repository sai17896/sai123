package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Customer;
import com.cg.service.IWalletService;

@RestController
public class WalletController {
@Autowired
IWalletService iWalletService;
@Autowired
Customer customer;

@PostMapping(value="/create",consumes= {MediaType.APPLICATION_JSON_VALUE})
public Customer addCustomer(@RequestBody Customer customer) {
	return iWalletService.createAccount(customer);
}

@GetMapping(value="/show/{mobileNo}")
public double showBalance(@PathVariable String mobileNo)
{
return 	iWalletService.showBalance(mobileNo);
}

@PostMapping(value="/deposit/{sourceMobile}/{amount}",consumes= {MediaType.APPLICATION_JSON_VALUE})
public boolean deposit(@PathVariable String sourceMobile,@PathVariable Double amount) {
	return 	iWalletService.deposit(sourceMobile,amount);
}

@PostMapping(value="/withdraw/{sourceMobile}/{amount}",consumes= {MediaType.APPLICATION_JSON_VALUE})
public boolean withdraw(@PathVariable String sourceMobile,@PathVariable Double amount) {
	return 	iWalletService.withdraw(sourceMobile,amount);
}

@PostMapping(value="/fund/{sourceMobile}/{recieverMobile}/{amount}",consumes= {MediaType.APPLICATION_JSON_VALUE})
public boolean fundTransfer(@PathVariable String sourceMobile,@PathVariable String recieverMobile, @PathVariable Double amount)
{
	
	return 	iWalletService.fundTransfer(sourceMobile,recieverMobile,amount);
}
}
