package com.cg.service;

import com.cg.beans.Customer;

public interface IWalletService {
	public Customer createAccount (Customer customer);
	public double showBalance(String sourceMobile);
	public boolean deposit(String sourceMobile, double amount);
	public boolean withdraw(String sourceMobile,double amount);
	public boolean fundTransfer(String sourceMobile,String receiverMobile, double amount);
}
