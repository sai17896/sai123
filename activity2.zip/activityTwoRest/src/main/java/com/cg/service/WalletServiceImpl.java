package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Wallet;
import com.cg.dao.WalletRepository;

@Service
public class WalletServiceImpl implements IWalletService {
@Autowired 
WalletRepository walletRepository;
	@Autowired
	Customer Customer;
	
	@Override
	public Customer createAccount(Customer customer) {
		Wallet wallet=new Wallet();
		wallet.setBalance(0);
		customer.setWallet(wallet);
		return walletRepository.save(customer);
	}

	@Override
	public double showBalance(String sourceMobile) {
		Customer cu= (Customer) walletRepository.findAllByMobileNo(sourceMobile);
		System.out.println(cu);
		return cu.getWallet().getBalance();
	}

	@Override
	public boolean deposit(String sourceMobile, double amount) {
		boolean result=false;
		Customer cu= (Customer) walletRepository.findAllByMobileNo(sourceMobile);
		double balance=cu.getWallet().getBalance()+amount;
		cu.getWallet().setBalance(balance);
	Customer c=	walletRepository.save(cu);
	if(c!=null)
		result=true;
		return result;
	}

	@Override
	public boolean withdraw(String sourceMobile, double amount) {
		boolean result=false;
		Customer cu= (Customer) walletRepository.findAllByMobileNo(sourceMobile);
		double balance=cu.getWallet().getBalance()-amount;
		cu.getWallet().setBalance(balance);
	Customer c=	walletRepository.save(cu);
	if(c!=null)
		result=true;
		return result;
	}

	@Override
	public boolean fundTransfer(String sourceMobile, String receiverMobile, double amount) {
		boolean result=false;
		Customer sender= (Customer) walletRepository.findAllByMobileNo(sourceMobile);	
		Customer receiver= (Customer) walletRepository.findAllByMobileNo(receiverMobile);
		System.out.println("sender: "+sender);
		System.out.println("receiver: "+receiver);
		double senderBal=sender.getWallet().getBalance()-amount;
		sender.getWallet().setBalance(senderBal);
		Customer s=	walletRepository.save(sender);
		double receiverBal=receiver.getWallet().getBalance()+amount;
		receiver.getWallet().setBalance(receiverBal);
		Customer r=	walletRepository.save(receiver);
		
		if(s!=null && r!=null)
			result=true;
		return result;
	}

}
