package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.WalletException;

public interface IWalletService {
	public Customer createAccount(Customer customer) throws WalletException;

	public double showBalance(int customerId) throws WalletException;

	public boolean deposit(int customerId, double amount) throws WalletException;

	public boolean withdraw(int customerId, double amount) throws WalletException;

	public boolean fundTransfer(int customerId, int customId, double amount) throws WalletException;

	List<Transaction> printTransaction(int customerId) throws WalletException;

	
	public Customer validateId(int customerId);

}
