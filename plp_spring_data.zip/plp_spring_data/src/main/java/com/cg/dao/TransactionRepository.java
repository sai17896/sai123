package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Integer> {

}
