package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.CreateAccount;
import com.cg.bean.Customer;

public class WalletUtility {
	
	public static Map<Integer, Customer> customerMap = new HashMap<>();
	static
	{
	   customerMap.put(177432,new Customer(177432,"Sairoop","17/08/1996","9640996045","sairoopappana123@gmail.com",new CreateAccount(177432,0.0),null));
	
	}


}
