package com.cg.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.bean.CreateAccount;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.exception.WalletApplicationException;
import com.cg.ui.Client;
import com.cg.util.WalletUtility;

public class WalletDaoImpl implements IWalletDao {

	static List<Transaction> transactionList = new ArrayList<>();
	
	public Customer createAccount(Customer customer)
	{
		WalletUtility.customerMap.put(customer.getCustomerId(), customer);
		return customer;
	}
	public double showBalance(int customerId) throws WalletApplicationException 
	{
		if(WalletUtility.customerMap.containsKey(customerId))
		{
			Customer customer = WalletUtility.customerMap.get(customerId);
			return customer.getAccount().getBalance();
		}
		else 
		{
			throw new WalletApplicationException("invalid customer id");
		}
	}

	public boolean deposit(int customerId, double amount)  throws WalletApplicationException 
	{
			if(WalletUtility.customerMap.containsKey(customerId))
		{
				Customer customer = WalletUtility.customerMap.get(customerId);
				double balance = customer.getAccount().getBalance()+amount;
				CreateAccount account = customer.getAccount();
				account.setBalance(balance);
				customer.setAccount(account);	
				int transactionId = (int) (Math.random()*10);
				Transaction transaction = new Transaction(transactionId,"Deposit",new Date(),0,amount);
				transactionList.add(transaction);
				customer.setTransationList(transactionList);
				return true;
		}
		else
		{
				throw new WalletApplicationException("invalid customer id");
		}
	}

	public boolean withdraw(int customerId, double amount) throws WalletApplicationException 
	{
			boolean result;
			Customer customer = WalletUtility.customerMap.get(customerId);
			if(customer.getAccount().getBalance()<amount)
		{
			throw new WalletApplicationException("Insufficient balance");
		}
		else
		{
			CreateAccount account = customer.getAccount();
			double balance = account.getBalance();
			balance = balance - amount;
			account.setBalance(balance);
			customer.setAccount(account);
			result = true;
			
			int transactionId = (int) (Math.random()*10);
			Transaction transaction = new Transaction(transactionId,"withdrawn",new Date(),0,amount);
			transactionList.add(transaction);
			customer.setTransationList(transactionList);
		}
			return result;
	}

	public boolean fundTransfer(int customerId, double amount) throws WalletApplicationException 
	{	
		boolean result;
		Customer senderCustomer = WalletUtility.customerMap.get(Client.customersId);
		if(senderCustomer.getAccount().getBalance()<amount) 
		{
			throw new WalletApplicationException("Insufficient balance");
		}
		else
		{
			Customer reciverCustomer = WalletUtility.customerMap.get(customerId);
			CreateAccount reciverAccount = reciverCustomer.getAccount();
			double reciverBalance = reciverAccount.getBalance();
			reciverBalance = reciverAccount.getBalance() + amount;
			reciverAccount.setBalance(reciverBalance);
			
			CreateAccount senderAccount = senderCustomer.getAccount();
			double senderBalance = senderAccount.getBalance();
			senderBalance = senderAccount.getBalance() - amount;
			senderAccount.setBalance(senderBalance);
			
			int transactionId = (int) (Math.random()*10);
			Transaction transaction = new Transaction(transactionId,"fund transfered",new Date(),reciverAccount.getAccountNo(),amount);
			transactionList.add(transaction);
			senderCustomer.setTransationList(transactionList);
			
			result = true;
		}
		return result;
	}

	public List<Transaction> printTransaction(int customerId)
	{
			Customer customer = WalletUtility.customerMap.get(customerId);
			return customer.getTransationList();
	}	
	
	public void addTransaction(Transaction transaction) {
		
	}

}
