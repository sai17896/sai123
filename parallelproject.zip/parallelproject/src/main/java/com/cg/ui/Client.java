package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.bean.CreateAccount;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.exception.WalletApplicationException;
import com.cg.service.IWalletService;
import com.cg.service.WalletServiceImpl;

public class Client {

	static IWalletService WalletService;
	public static int customersId;
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		WalletService = new WalletServiceImpl();
		System.out.println("Welcome to XYZ Bank");
		System.out.println("1.Create account ");
		System.out.println("2.Login");
		int option = scanner.nextInt();
		
		switch(option) {
		case 1:{
			System.out.println("Enter your name");
			String customerName = scanner.next();
			System.out.println("Enter your Date of birth");
			String dateOfBirth = scanner.next();
			System.out.println("Enter phone number");
			String phone  = scanner.next();
			System.out.println("Enter email");
			String email  = scanner.next();

			int custId = (int) (Math.random()*100); 
			
			long accountNo = (long) (Math.random()*100000); 
			double balance = 0.0;
			CreateAccount account = new CreateAccount(accountNo,balance);
			 
			Customer customer = new Customer(custId,customerName,dateOfBirth,phone,email,account,null);
			Customer createdCustomer = WalletService.createAccount(customer);
		
			System.out.println("Account created succesfully!! Your  customer id is "+createdCustomer.getCustomerId());
			String o = null;
			customersId = createdCustomer.getCustomerId();
			do {
			System.out.println("1.show balance\n2.deposit\n3.withdraw\n4.fundtransfer\n5.printtransaction");
			int opt = scanner.nextInt();
			switch(opt) {
			case 1:{
				System.out.println("enter customer id");
				int custid = scanner.nextInt();
				try {
					System.out.println("Your balance is "+WalletService.showBalance(custId));
				} catch (WalletApplicationException e) {
				
					e.printStackTrace();
				}
			}break;
			case 2:{
				System.out.println("enter your customer id and amount you want to deposit");
				int custid = scanner.nextInt();
				double amount = scanner.nextDouble();
				try {
					if(WalletService.deposit(custId, amount))
							System.out.println("amount deposited successfully");
					else 
						System.out.println("error occured");
				} catch (WalletApplicationException e) {
					e.printStackTrace();
				}
			}break;
			case 3:{
				System.out.println("enter your customer id and amount you want to withdraw");
				int custid = scanner.nextInt();
				double amount = scanner.nextDouble();
				try {
					if(WalletService.withdraw(custId, amount)) {
						System.out.println("amount withdrawed succesfully");
					}
					
				} catch (WalletApplicationException e) {
					e.printStackTrace();
				}
			}break;
			case 4:{
				System.out.println("Enter benificiary cutomer id and amount you want to transfer");
				int custid = scanner.nextInt();
				double amount = scanner.nextDouble();
				try {
					WalletService.fundTransfer(custId, amount);
				} catch (WalletApplicationException e) {
					e.printStackTrace();
				}
				
			}break;
			case 5:{
				System.out.println("Enter customer id");
				int custid = scanner.nextInt();
				List<Transaction> transationList =WalletService.printTransaction(custId);
			    for(Transaction transaction:transationList) {
			    	if(transaction.getTransactionType().equals("fund transfered"))
			    		System.out.println("Amount "+transaction.getAmount() +" " +transaction.getTransactionType()+" to customerId"+transaction.getToAccountNo()+" with transaction id "+transaction.getTransactionId()+" at "+transaction.getTransactionDate());
			    	else
			    	System.out.println("Amount "+transaction.getAmount() +" " +transaction.getTransactionType()+" with transaction id "+transaction.getTransactionId()+" at "+transaction.getTransactionDate());
			    }
			}
			}
			System.out.println("Press yes to continue");
			o = scanner.next();
			}while(o.equalsIgnoreCase("yes"));
			System.out.println("Thank You");
			
		}break;
		case 2:{

		}
		}

		scanner.close();
	}

}
