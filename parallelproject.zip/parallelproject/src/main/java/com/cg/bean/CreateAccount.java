package com.cg.bean;

public class CreateAccount {

	long accountNo; 
	double balance;	
	
	public CreateAccount() {
		super();
	}
	public CreateAccount(long accountNo, double balance) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	
	
	
}
