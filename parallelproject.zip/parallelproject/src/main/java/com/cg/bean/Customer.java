package com.cg.bean;

import java.util.List;

public class Customer {
	int customerid;
	String customerName;
	String dateofBirth;
	String phone;
	String email;

	CreateAccount account;
	List<Transaction> transationList;
	public Customer(int customerid, String customerName, String dateOfBirth, String phone, String email,
			 CreateAccount account, List<Transaction> transationList) {
		super();
		this.customerid = customerid;
		this.customerName = customerName;
		this.dateofBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
	
		this.account = account;
		this.transationList = transationList;
	}
	public int getCustomerId() {
		return customerid;
	}
	public void setCustomerId(int customerId) {
		this.customerid = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDateOfBirth() {
		return dateofBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateofBirth = dateOfBirth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public CreateAccount getAccount() {
		return account;
	}
	public void setAccount(CreateAccount account) {
		this.account = account;
	}
	public List<Transaction> getTransationList() {
		return transationList;
	}
	public void setTransationList(List<Transaction> transationList) {
		this.transationList = transationList;
	}
	
	

}
