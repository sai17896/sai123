package com.cg.service;

import java.util.List;


import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.exception.WalletApplicationException;

public interface IWalletService {
	
	public Customer createAccount (Customer customer);
	public double showBalance(int custId) throws WalletApplicationException;
	public boolean deposit(int customerId, double amount)  throws WalletApplicationException;
	public boolean withdraw(int customerId ,double amount) throws WalletApplicationException;
	public boolean fundTransfer(int customerId, double amount) throws WalletApplicationException;
	List<Transaction> printTransaction(int customerId);


}
