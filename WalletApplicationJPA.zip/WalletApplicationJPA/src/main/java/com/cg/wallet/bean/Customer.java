package com.cg.wallet.bean;

import java.io.Serializable;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Customer_wallet")
public class Customer implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="customer1seq",initialValue=100,allocationSize=1)
	@Column(length=30)
	int customerId;
	@Column(length=50)
	String customerName;
	@Column(length=10)
	String dateOfBirth;
	@Column(length=10)
	String phone;
	@Column(length=50)
	String email;
	@Column(length=30)
	String address;
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL)
List<Transaction> transactionList;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="accountNo")
	Account account;
	public Customer() {
		super();
	}
	
	public Customer(String customerName, String dateOfBirth, String phone, String email, String address,
			 Account account) {
		super();
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.account = account;

	}
	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public List<Transaction> getTransaction() {
		return transactionList;
	}

	public void setTransaction(List<Transaction> transaction) {
		this.transactionList = transaction;
	}

	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", dateOfBirth=" + dateOfBirth
				+ ", phone=" + phone + ", email=" + email + ", address=" + address + 
				", transactionList=" + transactionList + ", account=" + account + "]";
	}
	
    
}
