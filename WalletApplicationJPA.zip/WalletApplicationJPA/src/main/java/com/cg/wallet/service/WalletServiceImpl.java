package com.cg.wallet.service;

import java.util.List;
import java.util.Map;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;
import com.cg.wallet.dao.IWalletDao;
import com.cg.wallet.dao.WalletDaoImpl;
import com.cg.wallet.dao.WalletException;

public class WalletServiceImpl implements IWalletService {
IWalletDao dao=new WalletDaoImpl();
	public boolean createAccount(Customer customer) {
		return dao.createAccount(customer);
	}

	public double showBalance(int customerId) {
		return dao.showBalance(customerId);
	}

	public boolean deposit(int customerId, double amount) {
		return dao.deposit(customerId, amount);
	}

	public boolean withdraw(int customerId, double amount) {
		return dao.withdraw(customerId, amount);
	}

	public boolean fundTransfer(int customerId, double amount,int receipentId) {
		return dao.fundTransfer(customerId, amount,receipentId);
	}

	public List<Transaction> printTransaction(int customerId) {
		return dao.printTransaction(customerId);
	}

	@Override
	public Customer getById(int customerId) throws WalletException {
		return dao.getById(customerId);
	}



}
