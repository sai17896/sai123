package com.cg.wallet.ui;


import java.util.List;

import java.util.Scanner;

import com.cg.wallet.bean.Account;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;
import com.cg.wallet.dao.WalletException;
import com.cg.wallet.service.IWalletService;
import com.cg.wallet.service.WalletServiceImpl;

public class Client {

	public static void main(String[] args) {
		int choice=0;
Scanner scanner=new Scanner(System.in);
Scanner scanner2=new Scanner(System.in);
System.out.println("Select operation \n 1) Create Account \n 2) Login");
int ch=scanner.nextInt();
Customer customer=new Customer();
Account account=new Account();
List<Transaction> transactionList;
IWalletService service=new WalletServiceImpl();
switch (ch) {
case 1:
{

	System.out.println("Enter customer name : ");
	String customerName=scanner.next();
	System.out.println("Enter Date Of Birth in dd/MM/yyyy format : ");
	String dob=scanner.next();
	System.out.println("Enter phone number : ");
	String phone=scanner.next();
	System.out.println("Enter email ID : ");
	String email=scanner.next();
	System.out.println("Enter customer address : ");
	String address=scanner2.nextLine();

	int balance=0;
	
	// set customer data 
	
	
	customer.setCustomerName(customerName);
	customer.setAddress(address);
	customer.setDateOfBirth(dob);
	customer.setEmail(email);
	customer.setPhone(phone);
	
	// add account details
	account.setBalance(0);
	
	customer.setAccount(account);
	customer.setTransaction(null);
	boolean addCustomer= service.createAccount(customer);
	if (addCustomer) {
		System.out.println("Account created successfully with customer ID :"+customer.getCustomerId()+"!!!");
	}
	else {System.out.println("Account not created ..try again");}
	do {
		System.out.println("Select operation to perform \n 1. Show Balanace \n 2. Deposit \n 3. Withdraw \n 4.Fund Transfer \n 5. Print Transaction\n");
		int option=scanner.nextInt();
		switch (option) {
		case 1:
		{
		double bal=	service.showBalance(customer.getCustomerId());
		System.out.println("Your account number is :"+account.getAccountNo()+" and your balance is : "+bal);
		}
			break;
		case 2:
		{
			System.out.println("Enter amount you want to deposit in your wallet : ");
			double amount=scanner.nextDouble();
			boolean result=service.deposit(customer.getCustomerId(), amount);
			if(result)
			{
				System.out.println(amount+" is successfully deposited to your account "+account.getAccountNo());
			}
			else
			{
				System.out.println("Failed to deposit money..please try again later\n Thank You ");
			}
		}
			break;
		case 3:
		{
			System.out.println("Enter how much amount you want to withdraw??");
			double withdrawAmount=scanner.nextDouble();
			boolean result=service.withdraw(customer.getCustomerId(), withdrawAmount);
			if(result)
			{
				System.out.println(withdrawAmount+" is successfully withdraw from your account "+account.getAccountNo());
			}
			else
			{
				System.out.println("Failed to withdraw money..please try again later\n Thank You ");
			}
		}
			break;
		case 4:
		{
		System.out.println("Enter customerID to whom you want to transfer money..");
		int ReceiverCustomerId=scanner.nextInt();
		try {
			Customer customerRecipent=service.getById(ReceiverCustomerId);
			System.out.println("How much amount you want to transfer??");
			double amount=scanner.nextDouble();
			service.fundTransfer(customer.getCustomerId(),amount,ReceiverCustomerId);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		}
			break;
		case 5:
		{
			System.out.println("Enter customerID whose transation you wants to see..");
			int cId=scanner.nextInt();
			List<Transaction> tList=service.printTransaction(cId);
			System.out.println(tList);
			}
				break;
			default:
				System.out.println("Please select valid operation......");
				break;
			}
			System.out.println("Do you wants to continue? \n1. Yes\n 2. No");
			choice=scanner.nextInt();
	} while (choice==1);
}
	break;
case 2:
{
System.out.println("Enter Customer ID: ");
	int customerId=scanner.nextInt();
	Customer customerLogin=null;
	try {
		customerLogin = service.getById(customerId);
	} catch (WalletException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	do {
		System.out.println("Select operation to perform \n 1. Show Balanace \n 2. Deposit \n 3. Withdraw \n 4.Fund Transfer \n 5. Print Transaction\n");
		int option=scanner.nextInt();
		switch (option) {
		case 1:
		{
		double bal=	service.showBalance(customerLogin.getCustomerId());
		System.out.println("Your account number is :"+customerLogin.getAccount().getAccountNo()+" and your balance is : "+bal);
		}
			break;
		case 2:
		{
			System.out.println("Enter amount you want to deposit in your wallet : ");
			double amount=scanner.nextDouble();
			boolean result=service.deposit(customerLogin.getCustomerId(), amount);
			if(result)
			{
				System.out.println(amount+" is successfully deposited to your account "+customerLogin.getAccount().getAccountNo());
			}
			else
			{
				System.out.println("Failed to deposit money..please try again later\n Thank You ");
			}
		}
			break;
		case 3:
		{
			System.out.println("Enter how much amount you want to withdraw??");
			double withdrawAmount=scanner.nextDouble();
			boolean result=service.withdraw(customerLogin.getCustomerId(), withdrawAmount);
			if(result)
			{
				System.out.println(withdrawAmount+" is successfully withdraw from your account "+customerLogin.getAccount().getAccountNo());
			}
			else
			{
				System.out.println("Failed to withdraw money..please try again later\n Thank You ");
			}
		}
			break;
		case 4:
		{
		System.out.println("Enter customerID to whom you want to transfer money..");
		int ReceiverCustomerId=scanner.nextInt();
		try {
			Customer customerReceipent=service.getById(ReceiverCustomerId);
			System.out.println("How much amount you want to transfer??");
			double amount=scanner.nextDouble();
			service.fundTransfer(customerLogin.getCustomerId(),amount,ReceiverCustomerId);
		} catch (WalletException e) {
			e.printStackTrace();
		}
		}
			break;
		case 5:
		{
			System.out.println("Enter customerID whose transation you wants to see..");
			int cId=scanner.nextInt();
			List<Transaction> tList=service.printTransaction(cId);
			System.out.println(tList);
			}
				break;
			default:
				System.out.println("Please select valid operation......");
				break;
			}
			System.out.println("Do you wants to continue? \n1. Yes\n 2. No");
			choice=scanner.nextInt();
	} while (choice==1);
}
	break;
default:
	System.out.println("Invalid choice please select valid operation !!!");
	break;
}
scanner.close();
scanner2.close();
	}

}
