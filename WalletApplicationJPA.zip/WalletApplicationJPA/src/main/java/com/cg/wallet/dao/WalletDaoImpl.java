package com.cg.wallet.dao;

import java.util.ArrayList;
import java.util.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;

public class WalletDaoImpl implements IWalletDao{
//Account account;
Customer customer;
Transaction transaction=new Transaction();
EntityManagerFactory entityFactory;
EntityManager entityManager;
	EntityTransaction trans;
	public WalletDaoImpl() {
	super();
	entityFactory=Persistence.createEntityManagerFactory("jpa");
	entityManager=entityFactory.createEntityManager();
	trans=entityManager.getTransaction();
}

	public boolean createAccount(Customer customer) {
		this.customer=customer;
		boolean result=false;
		trans.begin();
		entityManager.persist(customer);
		trans.commit();
		Customer c1=entityManager.find(Customer.class, customer.getCustomerId());
		if(c1!=null) {result=true;}
		return result;
	}

	public double showBalance(int customerId) {
		Customer customer = entityManager.find(Customer.class, customerId);
		double balance = customer.getAccount().getBalance();
		return balance;
	}

	public boolean deposit(int customerId, double amount) {
		Customer customerDeposit;
		boolean result=false;
		try {
			customerDeposit = getById(customerId);
			
			double balance=showBalance(customerId)+amount;
			transaction.setTransactionType("Deposit");
			 Date date =new Date();
			    String strDateFormat = "hh:mm:ss a";
			    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
			    String formattedDate= dateFormat.format(date);
			  
			transaction.setTransactionDate(formattedDate);
			transaction.setToAccountNo(customerDeposit.getAccount().getAccountNo());
			transaction.setAmount(amount);
			transactionList.add(transaction);
			transaction.setCustomer(customerDeposit);
			customerDeposit.setTransaction(transactionList);
			customerDeposit.getAccount().setBalance(balance);

			//updating balance in customer
			trans.begin();
			Customer updatedCustomer=entityManager.merge(customerDeposit);
			trans.commit();
			Customer c1=entityManager.find(Customer.class, customerDeposit.getCustomerId());
			if(c1!=null) {result=true;}
		} catch (WalletException e) {
			e.printStackTrace();
		}
		
		return result;
	}

	public boolean withdraw(int customerId, double amount) {
		boolean result=false;
		Customer customerWithdraw;
		try {
			customerWithdraw = getById(customerId);
			double balance=showBalance(customerId);
			if(balance>=amount) {
				balance=balance-amount;
				customerWithdraw.getAccount().setBalance(balance);
				transaction.setTransactionType("Withdrawl");
				 Date date =new Date();
				    String strDateFormat = "hh:mm:ss a";
				    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
				    String formattedDate= dateFormat.format(date);
				  
				transaction.setTransactionDate(formattedDate);
				transaction.setToAccountNo(customerWithdraw.getAccount().getAccountNo());
				transaction.setAmount(amount);
				transaction.setCustomer(customerWithdraw);
				transactionList.add(transaction);
				customerWithdraw.setTransaction(transactionList);

				//updating balance in customer
				trans.begin();
				Customer updatedCustomer=entityManager.merge(customerWithdraw);
				trans.commit();
				Customer c1=entityManager.find(Customer.class, customerWithdraw.getCustomerId());
				if(c1!=null) {result=true;}
			}
		} catch (WalletException e) {
			e.printStackTrace();
		}
		
		return result;
	}

	public boolean fundTransfer(int customerId, double amount,int receipentId) {
		boolean result=false;
		try {
			
			Customer sender = getById(customerId);
			Customer receiver = getById(receipentId);
			if(sender.getAccount().getBalance()>=amount) {
				sender.getAccount().setBalance(sender.getAccount().getBalance()-amount);
				receiver.getAccount().setBalance(receiver.getAccount().getBalance()+amount);
				trans.begin();
				Customer updatedCustomer1=entityManager.merge(sender);
				Customer updatedCustomer=entityManager.merge(receiver);
				trans.commit();
				//add transaction details for sender
				
				transaction.setTransactionType("Fund transfer");
				 Date date =new Date();
				    String strDateFormat = "hh:mm:ss a";
				    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
				    String formattedDate= dateFormat.format(date);
				  
				transaction.setTransactionDate(formattedDate);
				transaction.setToAccountNo(receiver.getAccount().getAccountNo());
				transaction.setAmount(amount);
				transaction.setCustomer(sender);
				transactionList.add(transaction);
				sender.setTransaction(transactionList);
				
				//add transation details for receiver
				
				transaction.setTransactionType("Fund recieved");
				 Date date1 =new Date();
				    String strDateFormat1 = "hh:mm:ss a";
				    DateFormat dateFormat1= new SimpleDateFormat(strDateFormat1);
				    String formattedDate1= dateFormat1.format(date1);
				  
				transaction.setTransactionDate(formattedDate1);
				transaction.setToAccountNo(sender.getAccount().getAccountNo());
				transaction.setAmount(amount);
				transaction.setCustomer(receiver);
				transactionList.add(transaction);
				receiver.setTransaction(transactionList);
				result=true;
			}
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public List<Transaction> printTransaction(int customerId) {
		List<Transaction> t=new ArrayList<>();
		try {
			Customer customerTransaction= getById(customerId);
			t=customerTransaction.getTransaction();
		} catch (WalletException e) {
			System.out.println(e);
		}
		return t;
		
	}

	@Override
	public Customer getById(int customerId) throws WalletException {
		Customer cu2;
		try {
			cu2 = entityManager.find(Customer.class,customerId);
		} catch (Exception e) {
			throw new WalletException("Invalid Customer....Receiver customerId is not exists!!!");
		}
		return cu2;
	}

}
