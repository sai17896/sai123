package com.cg.wallet.service;

import java.util.List;


import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;
import com.cg.wallet.dao.WalletException;

public interface IWalletService {
	public boolean createAccount (Customer customer);
	public double showBalance(int customerId);
	public boolean deposit(int customerId, double amount);
	public boolean withdraw(int customerId ,double amount);
	public boolean fundTransfer(int customerId, double amount,int receipentId);
	List<Transaction> printTransaction(int custid);
	public Customer getById(int customerId) throws WalletException;
}
