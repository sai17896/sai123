package com.cg.wallet.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transaction;

public interface IWalletDao {
	Map<Integer, Customer> addCustomer=new HashMap<>();
	List<Transaction> transactionList=new ArrayList<>();
	public boolean createAccount (Customer customer); 
	public double showBalance(int customerId);
	public boolean deposit(int customerId, double amount);
	public boolean withdraw(int customerId, double amount);
	public boolean fundTransfer(int customerId, double amount,int receipentId);
	List<Transaction> printTransaction(int customerId);
	public Customer getById(int customerId) throws WalletException;

}
