package com.cg.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Product;
import com.cg.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService productService;
	@Autowired
	Product product;
	
	//POST
	//http://localhost:8083/addproduct
	@PostMapping("/addproduct/{id}/{name}/{model}/{price}")
	public Product addProduct(@PathVariable String id,@PathVariable String name,@PathVariable String model,@PathVariable Integer price) {
    product.setId(id);
		product.setName(name);
    product.setModel(model);
    product.setPrice(price);
	Product savedproduct=productService.addProduct(product);
	return savedproduct;
	}
	
	//POST 
	//http://localhost:8083/addproductobject send complete json data id
	@PostMapping(value="/addproductobject",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Product addProductObject(@RequestBody Product product) {
		Product savedproduct=productService.addProduct(product);
		return savedproduct;
	}
	
	//GET
	//http://localhost:8083/viewproducts
	@GetMapping("/viewproducts")
	public List<Product> viewProducts(){
		return productService.getProducts();
	}
	
	//DELETE
	//http://localhost:8083/deleteproductbyid/p22
	@DeleteMapping("/deleteproductbyid/{id}")
		public void deleteProductById(@PathVariable String id) {
			productService.deleteById(id);
		}
	
	//GET
	//http://localhost:8083/findbyid
	@GetMapping("/findbyid/{id}")
	public Product findById(@PathVariable String id) {
		return productService.findById(id);
	}
	
	//PUT
	//http://localhost:8083/updateproduct send complete json
	@PutMapping(value="/updateproduct",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Product updateProduct(@RequestBody Product product) {
		Product updatedProduct=productService.updateProduct(product);
		return updatedProduct;
	}
}
