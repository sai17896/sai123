package com.cg.service;

import java.util.List;

import com.cg.beans.Product;

public interface ProductService {
	public Product addProduct(Product p);
	public void deleteById(String id);
	
	public List<Product> getProducts();
	public Product findById(String id);
	Product updateProduct(Product p);

}
