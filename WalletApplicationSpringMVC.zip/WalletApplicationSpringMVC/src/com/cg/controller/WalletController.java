package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.dao.WalletException;
import com.cg.service.IWalletService;
@Controller
public class WalletController {
	@Autowired
	Customer customer;
	@Autowired
	IWalletService service;
	
	@RequestMapping("/")
	public ModelAndView first() {
	ModelAndView modelAndView=new ModelAndView();
	modelAndView.setViewName("login");
	return modelAndView;
	}
	
	@RequestMapping(value="/loginvalidation",method=RequestMethod.POST)
	public ModelAndView validate(@RequestParam int custId,
			HttpServletRequest request) 
	{
	ModelAndView modelAndView=new ModelAndView();
	HttpSession session=request.getSession();
	try {
		customer=service.validate(custId);
	} catch (WalletException e) {
		e.printStackTrace();
		modelAndView.addObject("message","Invalid customer Id");
		modelAndView.setViewName("exception");
		return modelAndView;
	}
	if(customer !=null) {
		session.setAttribute("customer", customer);
		modelAndView.setViewName("customerHome");	
	}
	else {
		modelAndView.addObject("status","Invalid username/password");
		modelAndView.setViewName("login");
	}
	return modelAndView;
	}
	
	@RequestMapping("/registerlink")
	public String registerlink(ModelMap map) {
	map.addAttribute(customer);
	return "addCustomer";
	}
	
	@RequestMapping("/register")
	public ModelAndView register(@Valid Customer customer,BindingResult errors)
	{
		ModelAndView modelAndView=new ModelAndView();
			boolean result=service.createAccount(customer);
			modelAndView.setViewName("login");
			if(result)
			modelAndView.addObject("status","registed successfully");
		return modelAndView;
	}
	
	@RequestMapping("/depositmoney")
	public String depositMoney(Model map,HttpServletRequest request) {
		return "depositMoney";
	}
	
	
	@RequestMapping("/deposit")
	public ModelAndView depositAmount(HttpServletRequest httpServletRequest,
			@RequestParam double amount) throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		System.out.println(customer);
		boolean result = service.deposit(customer.getCustomerId(), amount);
		if (result)
			httpSession.setAttribute("status", "Deposited amount: ");
		httpSession.setAttribute("amount", amount);
		modelAndView.setViewName("customerHome");
		return modelAndView; 
	}
	
	
	@RequestMapping("/showbalance")
	public ModelAndView ShowBalance(Model map,HttpServletRequest httpServletRequest) {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		System.out.println(customer);
		double balance = service.showBalance(customer.getCustomerId());
		httpSession.setAttribute("status", "Your account balance is");
		httpSession.setAttribute("amount", balance);
		modelAndView.setViewName("customerHome");
		return modelAndView;
	}
	
	@RequestMapping("/withdrawmoney")
	public String withdrawMoney(Model map,HttpServletRequest request) {
		return "withdrawMoney";
	}
	
	@RequestMapping("/withdraw")
	public ModelAndView withdrawAmount(HttpServletRequest httpServletRequest,
			@RequestParam double amount) throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		System.out.println(customer);
		boolean result = service.withdraw(customer.getCustomerId(), amount);
		if (result)
			httpSession.setAttribute("status", "Withdraw amount: ");
		httpSession.setAttribute("amount", amount);
		modelAndView.setViewName("customerHome");
		return modelAndView; 
	}
	
	@RequestMapping("/showtransaction")
	public ModelAndView viewTransactions(HttpServletRequest httpServletRequest) {
		ModelAndView modelAndView=new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		System.out.println(customer);
		List<Transaction> transactionList=service.printTransaction(customer.getCustomerId());
		modelAndView.addObject("transactionList", transactionList);
		httpSession.setAttribute("status", "Your Transactions: ");
		modelAndView.setViewName("customerHome");
		return modelAndView;
	}
	
	@RequestMapping("/transfermoney")
	public String transferMoney(Model map,HttpServletRequest request) {
		return "transferMoney";
	}
	
	@RequestMapping("/transfer")
	public ModelAndView transferAmount(HttpServletRequest httpServletRequest,
			@RequestParam double amount,@RequestParam int custId) throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		System.out.println(customer);
		boolean result = service.fundTransfer(customer.getCustomerId(), amount, custId);
		if (result)
			httpSession.setAttribute("status", "Transfered amount: ");
		httpSession.setAttribute("amount", amount);
		httpSession.setAttribute("status1", "To Customer with Id: ");
		httpSession.setAttribute("id", custId);
		modelAndView.setViewName("customerHome");
		return modelAndView; 
	}
	
	@RequestMapping("/login")
	public String login(Model map,HttpServletRequest httpServletRequest) {
		HttpSession httpSession = httpServletRequest.getSession();
		httpSession.setAttribute("status", "");
		httpSession.setAttribute("amount","");
		httpSession.setAttribute("status1", "");
		httpSession.setAttribute("id", "");
		return "login";
	}
	
}
