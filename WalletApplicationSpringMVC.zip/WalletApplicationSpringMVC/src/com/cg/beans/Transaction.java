package com.cg.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Transaction_wallet_spring")
@Component
public class Transaction implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="transactionspringseq",initialValue=300,allocationSize=1)
	@Column(length=10)
	int transactionId;
	@Column(length=20)
   	String transactionType;
	@Column(length=20)
	String transactionDate;
	@Column(length=20)
	int toAccountNo;
	@Column(length=20)
	double amount;
	@ManyToOne
	@JoinColumn(name="customerId")
	private Customer customer;
public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(String transactionType, String transactionDate, int toAccountNo,
			double amount) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.toAccountNo = toAccountNo;
		this.amount = amount;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getToAccountNo() {
		return toAccountNo;
	}
	public void setToAccountNo(int i) {
		this.toAccountNo = i;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "transactionId=" + transactionId + "\n transactionType=" + transactionType
				+ "\n transactionDate=" + transactionDate + "\n toAccountNo=" + toAccountNo + "\n amount=" + amount;
	}
	
}
