package com.cg.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.beans.Account;
import com.cg.beans.Customer;
import com.cg.beans.Transaction;


@Repository
public class WalletDaoImpl implements IWalletDao{
//Account account;
	@Autowired
Customer customer;
	@Autowired
Transaction transaction;
	
	@PersistenceContext
EntityManager entityManager;
	public WalletDaoImpl() {
	super();
}

	@Transactional
	@Override
	public boolean createAccount(Customer customer) {
		Account account=new Account();
		account.setBalance(0);
		customer.setAccount(account);
		customer.setTransactionList(null);
		this.customer=customer;
		boolean result=false;
		entityManager.persist(customer);
		Customer c1=entityManager.find(Customer.class, customer.getCustomerId());
		if(c1!=null) {result=true;}
		return result;
	}

	public double showBalance(int customerId) {
		Customer customer = entityManager.find(Customer.class, customerId);
		double balance = customer.getAccount().getBalance();
		return balance;
	}

	@Transactional
	@Override
	public boolean deposit(int customerId, double amount) {
		Customer customerDeposit;
		boolean result=false;
		try {
			customerDeposit = getById(customerId);
			
			double balance=showBalance(customerId)+amount;
			transaction.setTransactionType("Deposit");
			 Date date =new Date();
			    String strDateFormat = "hh:mm:ss a";
			    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
			    String formattedDate= dateFormat.format(date);
			transaction.setTransactionDate(formattedDate);
			transaction.setToAccountNo(customerDeposit.getAccount().getAccountNo());
			transaction.setAmount(amount);
			transactionList.add(transaction);
			transaction.setCustomer(customerDeposit);
			customerDeposit.setTransactionList(transactionList);
			customerDeposit.getAccount().setBalance(balance);
			//updating balance in customer
			Customer updatedCustomer=entityManager.merge(customerDeposit);
			Customer c1=entityManager.find(Customer.class, customerDeposit.getCustomerId());
			if(c1!=null) {result=true;}
		} catch (WalletException e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Transactional
	@Override
	public boolean withdraw(int customerId, double amount) {
		boolean result=false;
		Customer customerWithdraw;
		try {
			customerWithdraw = getById(customerId);
			double balance=showBalance(customerId);
			if(balance>=amount) {
				balance=balance-amount;
				customerWithdraw.getAccount().setBalance(balance);
				transaction.setTransactionType("Withdrawl");
				 Date date =new Date();
				    String strDateFormat = "hh:mm:ss a";
				    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
				    String formattedDate= dateFormat.format(date);
				  
				transaction.setTransactionDate(formattedDate);
				transaction.setToAccountNo(customerWithdraw.getAccount().getAccountNo());
				transaction.setAmount(amount);
				transaction.setCustomer(customerWithdraw);
				transactionList.add(transaction);
				customerWithdraw.setTransactionList(transactionList);

				//updating balance in customer
				Customer updatedCustomer=entityManager.merge(customerWithdraw);
				Customer c1=entityManager.find(Customer.class, customerWithdraw.getCustomerId());
				if(c1!=null) {result=true;}
			}
		} catch (WalletException e) {
			e.printStackTrace();
		}
		
		return result;
	}

	@Transactional
	@Override
	public boolean fundTransfer(int customerId, double amount,int receipentId) {
		boolean result=false;
		try {
			
			Customer sender = getById(customerId);
			Customer receiver = getById(receipentId);
			if(sender.getAccount().getBalance()>=amount) {
				sender.getAccount().setBalance(sender.getAccount().getBalance()-amount);
				receiver.getAccount().setBalance(receiver.getAccount().getBalance()+amount);
				Customer updatedCustomer1=entityManager.merge(sender);
				Customer updatedCustomer=entityManager.merge(receiver);
				//add transaction details for sender
				
				transaction.setTransactionType("Fund transfer");
				 Date date =new Date();
				    String strDateFormat = "hh:mm:ss a";
				    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
				    String formattedDate= dateFormat.format(date);
				  
				transaction.setTransactionDate(formattedDate);
				transaction.setToAccountNo(receiver.getAccount().getAccountNo());
				transaction.setAmount(amount);
				transaction.setCustomer(sender);
				transactionList.add(transaction);
				sender.setTransactionList(transactionList);
				
				//add transation details for receiver
				
				transaction.setTransactionType("Fund recieved");
				 Date date1 =new Date();
				    String strDateFormat1 = "hh:mm:ss a";
				    DateFormat dateFormat1= new SimpleDateFormat(strDateFormat1);
				    String formattedDate1= dateFormat1.format(date1);
				  
				transaction.setTransactionDate(formattedDate1);
				transaction.setToAccountNo(sender.getAccount().getAccountNo());
				transaction.setAmount(amount);
				transaction.setCustomer(receiver);
				transactionList.add(transaction);
				receiver.setTransactionList(transactionList);
				result=true;
			}
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public List<Transaction> printTransaction(int customerId) {
		List<Transaction> t=new ArrayList<>();
		try {
			Customer customerTransaction= getById(customerId);
			t=customerTransaction.getTransactionList();
		} catch (WalletException e) {
			System.out.println(e);
		}
		return t;
		
	}

	@Override
	public Customer getById(int customerId) throws WalletException {
		Customer cu2;
		System.out.println(customerId+"fh");
		try {
			cu2 = entityManager.find(Customer.class,customerId);
		} catch (Exception e) {
			throw new WalletException("Invalid Customer....Receiver customerId is not exists!!!");
		}
		return cu2;
	}

	@Override
	public Customer validate(int custId) throws WalletException{
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c where c.customerId=?1",Customer.class);
		query.setParameter(1, custId);
		Customer customer;
		try {
			customer = query.getSingleResult();
		} catch (Exception e) {
			throw new WalletException("Invalid Customer....customerId is not exists!!!");
		}
		return customer;
	}

}
