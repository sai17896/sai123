package com.cg.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.dao.IWalletDao;
import com.cg.dao.WalletDaoImpl;
import com.cg.dao.WalletException;


@Service
public class WalletServiceImpl implements IWalletService {

	@Autowired
	IWalletDao dao;
	public boolean createAccount(Customer customer) {
		return dao.createAccount(customer);
	}

	public double showBalance(int customerId) {
		return dao.showBalance(customerId);
	}

	public boolean deposit(int customerId, double amount) {
		System.out.println("coming here");
		return dao.deposit(customerId, amount);
	}

	public boolean withdraw(int customerId, double amount) {
		return dao.withdraw(customerId, amount);
	}

	public boolean fundTransfer(int customerId, double amount,int receipentId) {
		return dao.fundTransfer(customerId, amount,receipentId);
	}

	public List<Transaction> printTransaction(int customerId) {
		return dao.printTransaction(customerId);
	}

	@Override
	public Customer getById(int customerId) throws WalletException
	{
		return dao.getById(customerId);
	}

	@Override
	public Customer validate(int custId) throws WalletException {
		return dao.validate(custId);
	}

	



}
