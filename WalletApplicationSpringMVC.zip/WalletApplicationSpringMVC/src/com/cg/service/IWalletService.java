package com.cg.service;

import java.util.List;
import java.util.Map;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.dao.WalletException;



public interface IWalletService {
	public boolean createAccount (Customer customer);
	public double showBalance(int customerId);
	public boolean deposit(int customerId, double amount);
	public boolean withdraw(int customerId ,double amount);
	public boolean fundTransfer(int customerId, double amount,int receipentId);
	List<Transaction> printTransaction(int customerId);
	public Customer getById(int customerId) throws WalletException;
	public Customer validate(int custId) throws WalletException;
}
